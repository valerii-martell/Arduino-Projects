/*
 * DFPlayer Mini MP3/WAV Player
 *
 * SD card content:
 * - three folders: 01, mp3 and advert
 * - three files in the respective folders:
 *   - 01/001.mp3        for the playTrack(1, 1) call
 *   - mp3/0001.mp3      for the playMP3Folder(1) call
 *   - advert/0001.mp3   for the playAdvertFolder(1) call
 * - can have more folders from 01 to 99
 * - each folder can have more tracks from 001 to 255
 *   track names can be long filenames after the three digits in the mp3 and advert folders,
 *   or four digits in the 01 to 99 folders.
 *
 * Copyright 2019 Enoch Hwang
 */
#include <SoftwareSerial.h>
#ifndef DFPserial_RX
  // the default serial receive pin to use for communication with the DFPlayer
  #define DFPserial_RX 5
#endif
#ifndef DFPserial_TX
  // the default serial transmit pin to use for communication with the DFPlayer
  #define DFPserial_TX 4
#endif
SoftwareSerial DFPserial(DFPserial_TX, DFPserial_RX); // (Arduino_RX, Arduino_TX) - TX connect to RX and vice versa

class DFPlayer {
  private:
  	void sendPacket(byte CMD, byte Par1, byte Par2);// calling sendPacket() while a song is playing will cause popping noises
    bool receivePacket(uint8_t packet[]);
  public:
  	void begin();
    void playTrack(uint16_t filename);
  	void playTrack(uint8_t folder, uint8_t filename);
    void playMP3Folder(uint16_t filename);
    void playAdvertFolder(uint16_t filename);
    void playFolder(uint8_t folder);
    void playFolderRandom(uint8_t folder);
    void playAll();
    void repeatTrack(uint16_t filename);
    void nextTrack();
    void previousTrack();
    void stopAll();
    void stopPlay();
    void stopAdvertisement();
    int getCurrentTrack();
    int getNumberOfTracks();
    int getNumberOfTracks(uint8_t folder);
    int getNumberOfFolders();
  	bool SDCardInserted();
    int getPlayerStatus();
    void increaseVolume();
    void decreaseVolume();
    void setVolume(uint8_t vol);
    int getVolume();
  	void setEQ(uint8_t mode);
	  int getEQ();
    bool stopped();
    bool playing();
    bool playing(int pin);
    int readStatus(uint8_t statusCode);
    int readStatus2();
    void reset();
};

void DFPlayer::begin() {
  DFPserial.begin(9600);
	sendPacket(0x3F, 0x00, 0x00);	 // Send request for initialization parameters
	// delay(4000);	// need this delay for the DFPlayer to initialize
}


// play global file number
// folder names and filenames can be anything
void DFPlayer::playTrack(uint16_t filename) {
  uint8_t par1 = filename >> 8;
  uint8_t par2 = filename & 0x00ff; 
  sendPacket(0x03, par1, par2);
}


// SD://01/001.mp3
// folder names: 01 to 99
// filename: 001.mp3 to 255.mp3
// folder names must be two digits
// filenames must start with the 3 digits and optionally have a long filename after
void DFPlayer::playTrack(uint8_t folder, uint8_t filename) {
	sendPacket(0x0F, folder, filename);
}

// SD://mp3/0001.mp3
// folder name: mp3
// filename: 0001.mp3 to 3000.mp3
// filenames must start with the 4 digits and optionally have a long filename after
void DFPlayer::playMP3Folder(uint16_t filename) {
	uint8_t par1 = filename >> 8;
	uint8_t par2 = filename & 0x00ff; 
	sendPacket(0x12, par1, par2);
}

// SD://advert/0001.mp3
// folder name: advert
// filename: 0001.mp3 to 3000.mp3
// filenames must start with the 4 digits and optionally have a long filename after
void DFPlayer::playAdvertFolder(uint16_t filename) {
  uint8_t par1 = filename >> 8;
  uint8_t par2 = filename & 0x00ff; 
  sendPacket(0x13, par1, par2);
}

// Repeat playback of all tracks inside a folder
// folder names: 01 to 99
void DFPlayer::playFolder(uint8_t folder) {
  sendPacket(0x17, 0x00, folder);
}

// Randomly select a song in given folder to play
void DFPlayer::playFolderRandom(uint8_t folder) {
  int n = getNumberOfTracks(folder);
  int r = random(1, n+1);
  playTrack(folder, r);
}

void DFPlayer::playAll() {
  sendPacket(0x11, 0x00, 0x01);
}

// Set repeat playback of current track
void DFPlayer::repeatTrack(uint16_t filename) {
  uint8_t par1 = filename >> 8;
  uint8_t par2 = filename & 0x00ff; 
  sendPacket(0x08, par1, par2);
}

void DFPlayer::nextTrack() {
  sendPacket(0x01, 0x00, 0x00);
}

void DFPlayer::previousTrack() {
  sendPacket(0x02, 0x00, 0x00);
}

void DFPlayer::stopAll() {
  sendPacket(0x11, 0x00, 0x00);
}

void DFPlayer::stopPlay() {
  sendPacket(0x16, 0x00, 0x00);
}

void DFPlayer::stopAdvertisement() {
  sendPacket(0x15, 0x00, 0x00);
}

// get current track playing
int DFPlayer::getCurrentTrack() {
  sendPacket(0x4C, 0x00, 0x00);
  return readStatus(0x4C);
}

// Query number of tracks in the root of SD card
int DFPlayer::getNumberOfTracks() {
  sendPacket(0x48, 0x00, 0x00);
  return readStatus(0x48);
}

// Query number of tracks in folder
int DFPlayer::getNumberOfTracks(uint8_t folder) {
  sendPacket(0x4E, 0x00, folder);
  return readStatus(0x4E);
}

// Query number of folder
int DFPlayer::getNumberOfFolders() {
  sendPacket(0x4F, 0x00, 0x00);
  return readStatus(0x4F);
}

enum SDCardStatus {
	REMOVED = 1,
	INSERTED = 2
};

// Query SD card status
bool DFPlayer::SDCardInserted() {
  sendPacket(0x3F, 0x00, 0x00);
  if (readStatus(0x3F) == INSERTED) {
	return true;
  } else {
	return false;
  }
}

enum playerStatus {
	STOPPED,
	PLAYING,
	PAUSED
};

// Query player status
int DFPlayer::getPlayerStatus() {
  sendPacket(0x42, 0x00, 0x00);	// continuously calling this will cause popping noises
  int s = readStatus(0x42);
  // Serial.print(" getPlayerStatus = ");
  // Serial.println(s);
  if (s == -1) s = PLAYING;
  else if (s > PAUSED) s = PLAYING;
  return s;
}

void DFPlayer::increaseVolume() {
  sendPacket(0x04, 0x00, 0x00);  
}

void DFPlayer::decreaseVolume() {
  sendPacket(0x05, 0x00, 0x00);  
}

void DFPlayer::setVolume(uint8_t vol) {
  if (vol >= 0 && vol <= 30) {
    sendPacket(0x06, 0x00, vol);
  }
}

int DFPlayer::getVolume() {
  sendPacket(0x43, 0x00, 0x00);
  return readStatus(0x43);
}

void DFPlayer::setEQ(uint8_t mode) {
  // mode is: 0=normal; 1=pop; 2=rock; 3=jazz; 4=classic; 5=bass
  sendPacket(0x07, 0x00, mode);  
}

enum EQMode {
	NORMAL,
	POP,
	ROCK,
	JAZZ,
	CLASSIC,
	BASS
};

// Query EQ status
int DFPlayer::getEQ() {
  // mode is: 0=normal; 1=pop; 2=rock; 3=jazz; 4=classic; 5=bass
  sendPacket(0x44, 0x00, 0x00);  
  return readStatus(0x44);
}

// software solution to test for end of song after playing
// will return false if playing or when player is idle so this is not correct
bool DFPlayer::stopped() {
  if (readStatus(0x3D) > 0) {
	  return true;
  } else {
	  return false;	// when playing or player is idle
  }
}

// software solution to test for end of song after playing
// continuously calling this routine while playing a song will cause popping noises
bool DFPlayer::playing() {
  if (getPlayerStatus() == PLAYING) {
	  return true;
  } else {
	  return false;
  }
}

// hardware solution to test for end of song (better)
// works after calling stopPlay()
// using the DFPlayer Busy pin 16
// An Arduino pin connected to DFPlayer Busy pin 16
bool DFPlayer::playing(int Arduinopin) {
  pinMode(Arduinopin, INPUT); // this is needed only if using the same pin as the status led pin
  // HIGH = stopped; LOW = playing
  if (digitalRead(Arduinopin) == LOW) {
    pinMode(Arduinopin, OUTPUT); // this is needed only if using the same pin as the status led pin
    return true; // song playing
  } else {
    pinMode(Arduinopin, OUTPUT); // this is needed only if using the same pin as the status led pin
    return false;  // song stopped
  }
}

int DFPlayer::readStatus(uint8_t statusCode = 0x00) {
  bool debug=false;
  uint8_t p[10] = {0};  
  if (receivePacket(p)) { 
    switch(p[3]) {  // command code
      case 0x3A:
        if (true) Serial.println("Status: SD card inserted");
          playTrack(1);
        return p[6];
      case 0x3B:
        if (true) Serial.println("Status: SD card removed");
        return p[6];
      case 0x3D:
        // will not receive a packet if still playing
        // so will return a -1 if still playing
        if (debug) {
          Serial.print("Status: Finished playing global track: ");
          Serial.println(p[6], DEC);
        }
        if (p[3] == statusCode) {
          return p[6];
        } else {
          return -1;
        }
      case 0x3F:// this status code is received only after calling SDCardInserted()
        if (debug) {
          Serial.print("Status: SD card status: ");
          if (p[6] == INSERTED) Serial.println("inserted");	
          else if (p[6] == REMOVED) Serial.println("removed");
          else Serial.println("unknown");
        }
        return p[6];
      case 0x40:
        // also get this 0x40 if after calling getNumberOfTracks(folder) with command 0x4E and the folder is empty
        // this is something to do
        if (true) {
          Serial.print("Status: Error: ");
          Serial.println(p[6], HEX);
        }
        return p[6];
      case 0x41:
        if (debug) {
          Serial.print("Status: Received acknowledge: ");
          Serial.println(p[6], HEX);
        }
        return p[6];
      case 0x42:// this status code is received only after calling getPlayerStatus()
        if (debug) {
          Serial.println("Status: In readStatus code 0x42");
        }
        if (p[3] == statusCode) {
          if (p[5] == 0x02) {
            if (true) {
              Serial.print("Status: Current player status: ");
              if (p[6] == STOPPED) Serial.println(" stopped");
              else if (p[6] == PLAYING) Serial.println(" playing");
              else if (p[6] == PAUSED) Serial.println(" paused");
              else {
                Serial.print(" unknown ");// p[6] has the global track number that is currently playing
                Serial.println(p[6]);
              }
            }
            if (p[6] > PAUSED) p[6] = PLAYING;// p[6] has the global track number
            return p[6];
          } else {
            return -1;
          }
        } else {
          return -1;
        }
      case 0x43:// this status code is received only after calling getVolume()
        if (debug) {
          Serial.print("Status: Volume: ");
          Serial.println(p[6], DEC);
        }
        return p[6];
      case 0x44:// this status code is received only after calling getEQ()
        if (debug) {
          Serial.print("Status: EQ: ");
          Serial.println(p[6], DEC);
        }
        if (p[3] == statusCode) {
          return p[6];
        } else {
          return -1;
        }
      case 0x48:// this status code is received only after calling getNumberOfTracks()
        if (debug) {
          Serial.print("Status: Total number of tracks on SD card: ");
          Serial.println(p[6], DEC);
        }
        if (p[3] == statusCode) {
          return p[6];
        } else {
          return -1;
        }
      case 0x4C:// this status code is received only after calling getCurrentTrack()
        if (debug) {
          Serial.print("Status: Current track: ");
          Serial.println(p[6], DEC);
        }
        if (p[3] == statusCode) {
          return p[6];
        } else {
          return -1;
        }
      case 0x4E:// this status code is received only after calling getNumberOfTracks(folder)
        if (debug) {
          Serial.print("Status: Number of tracks in folder: ");
          Serial.println(p[6], DEC);
        }
        if (p[3] == statusCode) {
          return p[6];
        } else {
          return -1;
        }
      case 0x4F:// this status code is received only after calling getNumberOfFolders()
        if (debug) {
          Serial.print("Status: Total number of folders: ");
          Serial.println(p[6]-1, DEC);  // it's always one more than the actual
        }
        if (p[3] == statusCode) {
          return p[6]-1;  // it's always one more than the actual
        } else {
          return -1;
        }
      default:
        Serial.print("Status: undefined status code ");
        Serial.println(p[3]);
        if (debug) {
          for (int i=0; i<10; i++) {
            Serial.print(p[i], HEX);
            Serial.print(" ");
          }
          Serial.println();
        }
        return -1;
    }	// end switch
		
  } else {	// did not received a packet or received an error packet
    if (debug) {
      Serial.print("Status: Received packet error: ");
      for (int i=0; i<10; i++) {
        Serial.print(p[i], HEX);
        Serial.print(" ");
      }
      Serial.println();
    }
    return -1;
  }
  return -1;
}


void DFPlayer::reset() {
  sendPacket(0x0C, 0x00, 0x00);
  readStatus(0x0C);
}

bool DFPlayer::receivePacket(uint8_t p[]) {
  bool debug=false;
  for (int i=0; i<10; i++) {
    p[i] = 0;
  }
  int i=0;
  // wait for start byte 0x7E
  while (DFPserial.available()) {
    p[i] = DFPserial.read();
    if (p[i] == 0x7E) break;  // received start byte
  }
  i++;
  // receive until end byte 0xEF
  while (DFPserial.available()) {
    p[i] = DFPserial.read();
    if (p[i] == 0xEF) break;  // received end byte
    i++;
  }
  DFPserial.flush();  // empty the serial stream
  if (debug) {
    Serial.print("receivePacket: ");
    for (int i=0; i<10; i++) {
      Serial.print(p[i], HEX);
      Serial.print(" ");
    }
    Serial.println();
  }
  // optional if you want to do error checking
  if ((p[0] == 0x7E) && (p[1] == 0xFF) && (p[2] == 0x06) && (p[9] == 0xEF)) {
    return true;
  } else {
    return false;
  }
}

/*
bool DFPlayer::receivePacket(uint8_t packet[]) {
  int n;
  do {	// wait for the start code 0x7E
    if (DFPserial.available()) {
      n = DFPserial.readBytes(packet, 1);	// read 1 byte
    } else {
      Serial.println("receivedPacket: did not get start byte 0x7E");
      return false;
    }
  } while (packet[0] != 0x7E);
  // got the start code. now read 9 more bytes
  n += DFPserial.readBytes(packet+1, 9);
  // readBytes() is supposed to return the actual number of bytes read (according to the doc)
  // but it is always returning a -1. So cannot use the following if () 
  // if (n < 10) {
	  // not enough bytes read, corrupted packet
    // Serial.print("receivedPacket: not enough bytes read. n=");
    // Serial.println(n);
	  // return false;
  // }
  // if (packet[1] != 0xFF || packet[2] != 0x06 || packet[9] != 0xEF) {
  if (packet[1] != 0xFF || packet[2] != 0x06) { // sometimes don't get the ending byte but packet is still ok
	  // corrupted packet received
    Serial.println("receivedPacket: corrupted packet received");
	  return false;
  }
  DFPserial.flush();
  return true;
}
*/

// Execute the DFPlayer command with two parameters
// continuously calling sendPacket() while a song is playing will cause popping noises
void DFPlayer::sendPacket(uint8_t CMD, uint8_t Par1, uint8_t Par2) {   
  # define Start_Byte   0x7E  
  # define Version_Byte  0xFF  
  # define Command_Length 0x06  
  # define Acknowledge  0x00  // 0x00=no ack, 0x01=ack   
  # define End_Byte    0xEF  
  // Calculate the checksum (2 bytes)  
  uint16_t checksum = -(Version_Byte + Command_Length + CMD + Acknowledge + Par1 + Par2);  
  // Build the command line  
  uint8_t Command_line[10] = { Start_Byte, Version_Byte, Command_Length, CMD, Acknowledge,  
         Par1, Par2, highByte(checksum), lowByte(checksum), End_Byte};  
  // Send the command line to DFPlayer  
  for (int i=0; i<10; i++) {
	  DFPserial.write(Command_line[i]);
  }
  delay(200);  // need to have this delay between send commands
}  